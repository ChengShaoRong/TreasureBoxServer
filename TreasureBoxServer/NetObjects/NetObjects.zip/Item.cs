namespace TreasureBox
{
	public sealed class Item : Item_Base
	{ 
	} 
}
