/*
* C#Like 
* Copyright © 2022-2023 RongRong 
* It's automatic generate by KissEditor, don't modify this file. 
*/

namespace TreasureBox
{
	public class LogManagerEnum
	{
		public enum LogAccountType
		{
			Login,
			Logout,
			Register
		}
		public enum LogItemType
		{
			None,
			Mail,
			SignIn,
		}
	}
}
